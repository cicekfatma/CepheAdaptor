package Odemeler;

public interface OdemeYontemi {
    public void odemeYap(double tutar);
}
