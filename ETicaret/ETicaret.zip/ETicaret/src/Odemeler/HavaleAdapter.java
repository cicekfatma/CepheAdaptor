package Odemeler;

public class HavaleAdapter implements OdemeYontemi{
    @Override
    public void odemeYap(double tutar) {

    }
}
