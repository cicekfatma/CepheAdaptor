package Odemeler;

public class KrediKartiServisi {
    protected void krediKartiylaOde(double tutar){
        System.out.println(tutar+"miktarı kredi kartı ile ödendi.");

    }
}
