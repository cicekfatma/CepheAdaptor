package Odemeler;

public class NakitOdemeAdapter implements OdemeYontemi{
    @Override
    public void odemeYap(double tutar) {

    }
}
