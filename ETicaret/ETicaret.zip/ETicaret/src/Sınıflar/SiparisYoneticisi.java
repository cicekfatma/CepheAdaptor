package Sınıflar;

public class SiparisYoneticisi {

    private StokSistemi stokSistemi = new StokSistemi();

    public void siparisisle(String urunKodu, int miktar){
        boolean stoktaVarmi = stokSistemi.stokKontrolEt(urunKodu);
        if(stoktaVarmi){
            stokSistemi.stokGuncelle(urunKodu,miktar);
        }
        else{
            System.out.println("Sipariş iptal edildi,ürün stokta yok");
        }
    }
}
